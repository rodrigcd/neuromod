class BaseNetwork(object):

    def train_step(self):
        pass