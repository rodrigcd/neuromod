class BaseTask(object):

    def sample_batch(self):
        pass

    def get_correlation_matrix(self):
        pass